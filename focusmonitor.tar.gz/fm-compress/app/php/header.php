<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- icons -->
<script src="https://kit.fontawesome.com/7c4066689f.js" crossorigin="anonymous"></script>

<!-- css -->
<link rel="stylesheet" href="../css/main/dash_index.css">

<link rel="stylesheet" href="../css/main/dash_node.css">
<link rel="stylesheet" href="../css/main/main.css">
<!-- D3 library -->
<script src="http://d3js.org/d3.v3.min.js"></script>
<script src="https://d3js.org/d3.v4.js"></script>
<!-- js -->
<script src="../js/index.js"></script>
<script src="../js/charts/index.js"></script>

<link rel="icon" type="image/x-icon" href="../../img/ico/eye_backCircle.ico">
