<?php
    session_start();

    require_once 'db/db_connection.php';
    require_once 'user.php';



?>